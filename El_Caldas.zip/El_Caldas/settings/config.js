const config = {
        botName: 'El_Caldas',
        ownerName: 'Caldas',
        youtube: 'YOUTUBE_LINK',
        instagram: 'INSTAGRAM_LINK',
}
