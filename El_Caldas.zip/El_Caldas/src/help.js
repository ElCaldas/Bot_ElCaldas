const help = (prefix) => { 
	return `   

「 *Bot El_Caldas* 」

◪ *informações*
  ❏ Prefix: 「  )  」
  ❏ Criador : Caldas

 *se o bot não responder conte até 10 e tente novamente*
  mais informações:
👇
wa.me/556993270820

Canal do criador: 

◪ *SOBRE*
  │
  ├─ ❏ )info
  ├─ ❏ )blocklist
  ├─ ❏ )chatlist
  ├─ ❏ )ping
  └─ ❏ )bugreport
◪ *FAZER*
  │
  ├─ ❏ )sticker
(faz figurinha animada e normal)
  ├─ ❏ )stickergif
(faz figurinha animada a msm coisa de cima)
  ├─ ❏ )toimg
(converte Sticker em imagens)
  ├─ ❏ )tomp3
  ├─ ❏ )bpink
  ├─ ❏ )marvellogo
  ├─ ❏ )snowwrite
  ├─ ❏ )3dtext
  ├─ ❏ )ninjalogo
  ├─ ❏ )water
  ├─ ❏ )firetext
  ├─ ❏ )logowolf
  ├─ ❏ )logowolf2
  ├─ ❏ )phlogo
  ├─ ❏ )glitch
  ├─ ❏ )neonlog
  ├─ ❏ )neonlogo2
  ├─ ❏ )lionlogo
  ├─ ❏ )jokerlogo
  ├─ ❏ )shadow
  ├─ ❏ )burnpaper
  ├─ ❏ )coffee
  ├─ ❏ )lovepaper
  ├─ ❏ )woodblock
  ├─ ❏ )qowheart
  ├─ ❏ )mutgrass
  ├─ ❏ )undergocean
  ├─ ❏ )woodenboards
  ├─ ❏ )wolfmetal
  ├─ ❏ )metalictglow
  ├─ ❏ )8bit
  ├─ ❏ )ttp
  ├─ ❏ )herrypotter
  ├─ ❏ )pubglogo
  └─ ❏ )quotemaker
◪ *MEDIA*
  │
  ├─ ❏ )trendtwit
  ├─ ❏ )randomkpop
  └─ ❏ )ytsearch
◪ *EDUCATION*
  │
  ├─ ❏ )wiki
  ├─ ❏ )wikien
  ├─ ❏ )nulis
  ├─ ❏ )quotes
  ├─ ❏ )quotes2
  └─ ❏ )artinama
◪ *KERANG AJAIB*
  │
  ├─ ❏ )apakah
  ├─ ❏ )kapankah
  ├─ ❏ )rate
  └─ ❏ )bisakah
◪ *DOWNLOADER*
  │
  ├─ ❏ )images
  ├─ ❏ )ytmp3
  ├─ ❏ )ytmp4
  ├─ ❏ )tiktok
  └─ ❏ )joox
◪ *MEME*
  │
  ├─ ❏ )meme
  └─ ❏ )memeindo
◪ *SOM*
  │
  ├─ ❏ )play
(abaixa música, só funciona se o título tiver certo)
  └─ ❏ )tts
(converte texto em áudio) mó legal ksksks
◪ *MÚSICA*
  │
  ├─ ❏ )lirik
  └─ ❏ )chord
◪ *ISLAM*
  │
  └─ ❏ )quran
◪ *STALK*
  │
  ├─ ❏ )tiktokstalk
  └─ ❏ )igstalk
◪ *WIBU*
  │
  ├─ ❏ )neonime
  ├─ ❏ )pokemon
  ├─ ❏ )loli
(foto de loli😏) *as vezes não funciona*
  ├─ ❏ )waifu
  ├─ ❏ )randomanime
  ├─ ❏ )husbu
  ├─ ❏ )husbu2
  ├─ ❏ )wait
  └─ ❏ )nekonime
◪ *DIVERSÃO*
  │
  ├─ ❏ )alay
  ├─ ❏ )gantengcek
  ├─ ❏ )watak
  ├─ ❏ )hobby
  ├─ ❏ )game
  ├─ ❏ )bucin
  ├─ ❏ )trust
  ├─ ❏ )dare
  └─ ❏ )simi
◪ *INFORMAÇÃO*
  │
  ├─ ❏ )bahasa
  ├─ ❏ )kodenegara
  ├─ ❏ )kbbi
  ├─ ❏ )fakta
  ├─ ❏ )infocuaca
  ├─ ❏ )infogempa
  ├─ ❏ )jadwaltvnow
  └─ ❏ )covid
◪ *DONO*
  │
  ├─ ❏ )setprefix
  ├─ ❏ )block
  ├─ ❏ )bc
  ├─ ❏ )bcgc
  ├─ ❏ )clone
  └─ ❏ )clearall
◪ *OUTROS*
  │
  ├─ ❏ )send
  ├─ ❏ )wame
  ├─ ❏ )exe
  ├─ ❏ )qrcode
  ├─ ❏ )afk
  ├─ ❏ )timer
  ├─ ❏ )fml
  └─ ❏ )fml2
`
}
exports.help = help
